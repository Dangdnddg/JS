console.log("after creating variable of but without giving a value to x");

var x ;
console.log(x)
if(x == undefined)
{
    console.log("x is undefined");
}