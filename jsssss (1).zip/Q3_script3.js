console.log("passing x in console without creating variable");

console.log(x);