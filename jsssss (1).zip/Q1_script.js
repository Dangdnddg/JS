var y = "HELLO WORLD";
var x = "this file is linked with HTML";
var z = y+" "+ x;